package br.atos;

public class HelloWorld {
	public String getMessage() {
		return "JSF hello world example.";
	}
}
