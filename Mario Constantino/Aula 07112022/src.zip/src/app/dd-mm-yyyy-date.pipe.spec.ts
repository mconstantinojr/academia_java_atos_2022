import { DdMmYyyyDatePipe } from './dd-mm-yyyy-date.pipe';

describe('DdMmYyyyDatePipe', () => {
  it('create an instance', () => {
    const pipe = new DdMmYyyyDatePipe();
    expect(pipe).toBeTruthy();
  });
});
