export interface ModelProgramador {
  id: number;
  nome: string;
  salario: string;
  idade: string;
  dataNascimento: Date;
}
