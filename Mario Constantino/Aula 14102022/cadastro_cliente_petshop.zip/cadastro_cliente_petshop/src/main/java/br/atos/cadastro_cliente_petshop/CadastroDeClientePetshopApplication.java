package br.atos.cadastro_cliente_petshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroDeClientePetshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroDeClientePetshopApplication.class, args);
	}

}
