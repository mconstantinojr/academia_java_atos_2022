package br.atos.cadastro_cliente_petshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroDeClientePetshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
