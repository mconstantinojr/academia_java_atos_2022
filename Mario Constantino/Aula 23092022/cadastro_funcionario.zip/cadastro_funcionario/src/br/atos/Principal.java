package br.atos;

import br.atos.controller.ControleDeCadastro;

public class Principal {

	public static void main(String[] args) {
		ControleDeCadastro controleDeCadastro = new ControleDeCadastro();
		controleDeCadastro.inciarPrograma();

	}

}
