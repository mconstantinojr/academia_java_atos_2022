package br.atos.controller;

import br.atos.telas.MenuInicial;

public class ControleDeCadastro {
	
	public void inciarPrograma() {
		MenuInicial menuInicial = new MenuInicial();
		menuInicial.apresentarMenuInicial();
	}
	
	
}
