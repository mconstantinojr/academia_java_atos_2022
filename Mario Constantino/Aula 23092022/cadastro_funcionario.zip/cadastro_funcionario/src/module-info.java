/**
 * 
 */
/**
 * @author a804867
 *
 */
module cadastro_funcionario {
	requires java.desktop;
}