package br.impacta;

import br.impacta.controller.ControleDeCadastro;

public class PrincipalCadastroProgramador {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ControleDeCadastro controleDeCadastro = new ControleDeCadastro();
		controleDeCadastro.inciarPrograma();
	}

}
