package br.impacta.controller;

import br.impacta.telas.MenuInicial;

public class ControleDeCadastro {
	
	public void inciarPrograma() {
		MenuInicial menuInicial = new MenuInicial();
		menuInicial.apresentarMenuInicial();
	}
	
	
}
