/**
 * 
 */
/**
 * @author a804867
 *
 */
module cadastro_programador {
	requires java.desktop;
}