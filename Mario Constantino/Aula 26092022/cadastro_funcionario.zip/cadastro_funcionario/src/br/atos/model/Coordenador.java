package br.atos.model;

public class Coordenador extends Funcionario {
	
	private String loja;

	public String getLoja() {
		return loja;
	}

	public void setLoja(String loja) {
		this.loja = loja;
	}
	
	
}
