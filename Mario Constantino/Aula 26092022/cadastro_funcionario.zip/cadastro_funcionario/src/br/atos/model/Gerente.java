package br.atos.model;

public class Gerente extends Funcionario {
	
	public String regional;

	public String getRegional() {
		return regional;
	}

	public void setRegional(String regional) {
		this.regional = regional;
	}
	
	
}
