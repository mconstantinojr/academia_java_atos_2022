package br.atos.cadastro_animais_zoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroAnimaisZooApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroAnimaisZooApplication.class, args);
	}

}
