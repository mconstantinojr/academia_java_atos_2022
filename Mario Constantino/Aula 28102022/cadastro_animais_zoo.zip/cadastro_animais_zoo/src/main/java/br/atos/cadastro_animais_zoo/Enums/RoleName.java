package br.atos.cadastro_animais_zoo.Enums;

public enum RoleName {
	
	ROLE_ADMIN,
	ROLE_USER;
}
