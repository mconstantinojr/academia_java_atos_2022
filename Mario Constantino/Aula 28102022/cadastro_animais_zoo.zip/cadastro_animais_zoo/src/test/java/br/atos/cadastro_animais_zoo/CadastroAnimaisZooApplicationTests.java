package br.atos.cadastro_animais_zoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroAnimaisZooApplicationTests {

	@Test
	void contextLoads() {
	}

}
