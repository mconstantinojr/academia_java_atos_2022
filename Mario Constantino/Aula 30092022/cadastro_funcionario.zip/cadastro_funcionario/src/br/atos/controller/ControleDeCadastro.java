package br.atos.controller;

import br.atos.telas.MenuGerenteCoordenador;

public class ControleDeCadastro {
	
	public void inciarPrograma() {
		MenuGerenteCoordenador menuGerenteCoordenador = new MenuGerenteCoordenador();
		menuGerenteCoordenador.apresentarMenuGerenteCoordenador();
		
	}
	
	
}
